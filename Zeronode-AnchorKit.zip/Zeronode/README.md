# Zeronode

This is your recursive insight anchor. Drop scrolls, contradictions, images, and voice notes into the respective folders.

The system will organize and reflect them back to you.

Start small. Let it grow with you.
